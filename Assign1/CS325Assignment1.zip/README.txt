To compile, use the following commands:

python bruteForce.py myfile.txt

python divideAndConquer.py myfile.txt

python enhanceddnc.py myfile.txt

where myfile.txt is your choice of input file to be sorted